package com.hexaware.javabasics;

//basic example of java
/*
 * A simple program using java
 * which shows the structure of a java program
 */
public class HelloMavericks {

	public static void main(String[] args) {
		
		System.out.println("Hello Mavericks Welcome to Hexaware PGET Training Program");
	}

}
