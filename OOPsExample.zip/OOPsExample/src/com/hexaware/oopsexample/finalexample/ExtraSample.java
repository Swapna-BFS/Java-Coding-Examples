package com.hexaware.oopsexample.finalexample;

public class ExtraSample extends NewSample{

}
