package com.hexaware.oopsexample.finalexample;

public final class NewSample extends Sample{
	
	@Override
	public void methodOne(){
		System.out.println("Method One from NewSample.....");
	}
}
