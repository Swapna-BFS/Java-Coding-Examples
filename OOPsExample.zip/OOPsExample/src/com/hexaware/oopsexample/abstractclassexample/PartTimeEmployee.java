package com.hexaware.oopsexample.abstractclassexample;

public class PartTimeEmployee extends Employee{

	@Override
	public void calculateSalary() {
		// TODO Auto-generated method stub
		
	}

}
