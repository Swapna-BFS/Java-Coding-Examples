package com.hexaware.oopsexample.construtordemo;

public class ConstructorDemoMain {

	public static void main(String[] args) {
		
		//creating an object for Demo Class
		//Demo d = new Demo();
		
		
		//following create object will call param constructor
		//Demo d1 = new Demo(55, 66);
		
		//following create object will call copy constructor
		//Demo d2 = new Demo(d1);
		
		SampleDemo sd = new SampleDemo();
		

	}

}
