package com.hexaware.oopsexample.accessspecifiers;

public class MainProduct {

	public static void main(String[] args) {
		Product p = new Product();
		
		
	}

}
