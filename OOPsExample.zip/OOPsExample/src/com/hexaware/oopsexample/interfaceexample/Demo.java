package com.hexaware.oopsexample.interfaceexample;

public interface Demo extends Sample,NewSample {
	int a =89;
}
