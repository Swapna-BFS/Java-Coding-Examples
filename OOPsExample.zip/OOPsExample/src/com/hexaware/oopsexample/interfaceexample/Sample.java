package com.hexaware.oopsexample.interfaceexample;

public interface Sample {

}
