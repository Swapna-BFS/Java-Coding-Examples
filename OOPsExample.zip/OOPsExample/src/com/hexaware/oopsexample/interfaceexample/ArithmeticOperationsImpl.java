package com.hexaware.oopsexample.interfaceexample;

public class ArithmeticOperationsImpl implements ArithmeticOperations,Demo{

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return (5+6);
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return (5-6);
	}

	@Override
	public int mul(int a, int b) {
		// TODO Auto-generated method stub
		return (5*6);
	}

	@Override
	public int div(int a, int b) {
		// TODO Auto-generated method stub
		return (5/6);
	}

}
