package com.hexaware.oopsexample.staticexample;

public class Increment {
	static int i;
	public int increment(){
		return i++;
	}
}
