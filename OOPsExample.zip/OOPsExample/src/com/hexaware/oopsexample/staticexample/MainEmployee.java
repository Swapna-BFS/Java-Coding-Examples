package com.hexaware.oopsexample.staticexample;

public class MainEmployee {

	public static void main(String[] args) {
		Employee emp = new Employee();
		Employee.calculateSalary();
	}

}
