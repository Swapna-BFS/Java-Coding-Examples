package com.hexaware.oopsexample.polymorphism;

public class StudentMain {

	public static void main(String[] args) {
		
		FullTimeStudent  fts = new FullTimeStudent();
		fts.calculateResult();

	}

}
