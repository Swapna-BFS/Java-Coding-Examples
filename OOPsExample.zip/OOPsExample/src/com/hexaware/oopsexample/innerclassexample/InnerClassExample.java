package com.hexaware.oopsexample.innerclassexample;

public class InnerClassExample {

	public static void main(String[] args) {
		Outer.Inner n = new Outer.Inner();
		n.methodTwo();
	}

}
