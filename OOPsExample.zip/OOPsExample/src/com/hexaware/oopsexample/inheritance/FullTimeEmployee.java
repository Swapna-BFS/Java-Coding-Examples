package com.hexaware.oopsexample.inheritance;

public class FullTimeEmployee extends Employee {
	
	float fullTimeEmpSalary;
	
	void calculateFullTimeEmployeeSa(){
		System.out.println("This method calculates FullTimeEmployee salary...");
	}

}
