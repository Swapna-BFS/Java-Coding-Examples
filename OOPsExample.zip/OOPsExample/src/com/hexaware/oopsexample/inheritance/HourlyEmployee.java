package com.hexaware.oopsexample.inheritance;

public class HourlyEmployee extends ContractEmployee{
	float hourlyEmpSalary;
	
	void calculateHourlyEmpSalary(){
		System.out.println("This method calculates hourly emp salary...");
	}
}
